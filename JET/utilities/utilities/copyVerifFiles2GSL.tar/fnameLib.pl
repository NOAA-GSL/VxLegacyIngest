#! /usr/local/perl5/bin/perl
#-----------------------------------------------------------------------------
#  NOAA/ERL
#  Forecast Systems Laboratory
#  Facility Division
#  Central Facility Management Branch
#  
#  This software and its documentation are in the public domain and are
#  furnished "as is".  The United States Government, its instrumentalities,
#  officers, employees, and agents make no warranty, express or implied, as to
#  the usefulness of the software and documentation for any purpose.  They
#  assume no responsibility (1) for the use of the software and documentation;
#  or (2) to provide technical support to users.
#  
#  fnameLib.pl  --  functions to convert a time-based filename to C-time
#
#  Glen Pankow       3 Sep 97       1.1     Original version (extractDate)
#  Bob Lipschutz    11/25/97        1.1     as fnameLib.pl
#-----------------------------------------------------------------------------
# $Id: fnameLib.pl,v 1.3 2017/01/30 20:44:49 ewy Exp $

use Time::Local;

# $fmt   = "%y%j%H%M";

sub fname2time
{
    my ($srcFormat, $source) = @_;
    my (@parensTypes, $time, $offset, $srcFormatRE);

#------------------------------------------------------------------------------------
# If $srcFormat is defined, convert the it into a perl regular expression.
#------------------------------------------------------------------------------------
if (defined($srcFormat))
    {
    $srcFormatRE = &formatToRE($srcFormat, \@parensTypes);

# print "\$srcFormatRE = \"$srcFormatRE\"\n";
# for ($i = 0;  $i < @parensTypes;  ++$i)
#     {
#     print "\$parensTypes[$i] = \"$parensTypes[$i]\"\n";
#     }
    }

#
# If $source is defined, that means that the source (a single line only) was
# found directly on the command line.  Extract the time value $time from
# $source.
#
if (defined($source))
    {
    #
    # If $srcFormat is not defined, then $source (and thus the time value $time)
    # is in C epoch time.
    #
    if (!defined($srcFormat))
        {
        if (!($source =~ /(\d+)/))
            {
            print STDERR "! $0:  no matching date/time string found.\n";
            return 0;
            }
        $time = $source + $offset;
        }

    #
    # If $source matches the regular expression created from $srcFormat,
    # compute the time value $time from it.
    #
    elsif ($source =~ /$srcFormatRE/)
        {
# print "  YES!\n      \$1 = \"$1\"\n      \$2 = \"$2\"\n";
        $time = &computeCTime($offset, \@parensTypes,
                $1,  $2,  $3,  $4,  $5,  $6,  $7,  $8,  $9,
          $10, $11, $12, $13, $14, $15, $16, $17, $18, $19,
          $20, $21, $22, $23, $24, $25, $26, $27, $28, $29 );
        if ($time < 0)
            {
            $reason
              = ('month name', 'time zone', 'day of the year')[-1 - $time];
            print STDERR
              "! $0:  could not parse/convert the date/time string:\n",
              "!    bad $reason.\n";
            return 0;
            }
        }

    #
    # Otherwise we fail.
    #
    else
        {
        print STDERR "! $0:  no matching date/time string found.\n";
        return 0;
        }
    }

return $time;
}

#
# formatToRE()
#
# $formatRE = &formatToRE($format);
#
# Convert the format string $format to a perl regular expression.
#
# Recognized field descriptors:
#   %a -- abbreviated weekday name -- matches '[a-zA-Z]+' (not used in comput)
#   %A -- full weekday name -- matches '[a-zA-Z]' (not used in computation)
#   %b -- abbreviated month name -- matches '[a-zA-Z]+'
#   %B -- full month name -- matches '[a-zA-Z]+'
#   %c -- date/time as %a %b %d %H:%M:%S %Y ('C' locale only)
#   %d -- day of month (01 to 31) -- matches '[0-3]\d'
#   %D -- date as %m/%d/%y
#   %e -- day of month (1 to 31) -- matches '[\s1-3]\d'
#   %h -- abbreviated month name (alias for %b) -- matches '[a-zA-Z]+'
#   %H -- hour (00 to 23) -- matches '[0-2]\d'
#   %I -- hour (01 to 12) -- matches '[01]\d'
#   %j -- day of year (001 to 366) --  matches '[0-3]\d\d'
#   %m -- month of year (01 to 12) -- matches '[01]\d'
#   %M -- minute (00 to 59) -- matches '[0-5]\d'
#   %p -- ante-/post-meridiem indicator -- matches '[aApP][mM]' ('C' locale)
#   %r -- time as %I:%M:%S %p
#   %R -- time as %H:%M
#   %S -- second (00 to 61) -- matches '[0-6]\d'
#   %T -- time as %H:%M:%S
#   %U -- week number of year (00 to 53) (Sunday) -- matches '[0-5]\d' (unused)
#   %w -- day of week (Sunday = 0) -- matches '[0-6]' (not used in computation)
#   %W -- week number of year (00 to 53) (Monday) -- matches '[0-5]\d' (unused)
#   %x -- date as %m/%d/%y ('C' locale only)
#   %X -- time as %H:%M:%S ('C' locale only)
#   %y -- year within century (00 to 99) -- matches '\d\d'
#   %Y -- year as ccyy (4 digits) -- matches '[12]\d\d\d'
#   %Z -- timezone name -- matches '[A-Z]+'
#
# Unrecognized field descriptors:
#   %n -- newline (the pattern is not designed to span lines)
#   %t -- tab character (recognized under <whitespace>)
#
# And:
#   <whitespace> -- matches '\s+', except before a '%e' field descriptor, where
#       the whitespace must match itself exactly
#   <%anything> -- matches itself
#   <anything else> -- matches itself
#
# 'C' or 'English' locale is assumed.  This affects the interpretation of the
# %c, %p, %x, and %X field descriptors, as well as the day and month names.
#
sub formatToRE
    {
    my ($format,                # the format string to convert
        $parensTypesRef) = @_;  # reference to types of matching parens array
    my ($formatRE,              # the converted regular expression string
        $parensIdx);            # next index into types of mtchng parens array

    $formatRE = '';
    @$parensTypesRef = ();
    $parensIdx = 0;
    while ($format)
        {
# print "\$format = \"$format\"\n";
        if ($format =~ /^(\s+)(.*)/)                # whitespace
            {
            $formatRE .= ((length($2) >= 2) && (substr($2, 0, 2) eq '%e'))?
              $1 : '\\s+';
            $format = $2;
# print "   <spaces>...\n";
            }
        elsif ($format =~ /^([^%\s]+)(.*)/)     # not a field directive substr
            {
            $formatRE .= &protectChars($1);
            $format = $2;
# print "   <leading stuff>...\n";
            }
        elsif ($format =~ /^%y(.*)/)            # year within century
            {
            $$parensTypesRef[$parensIdx++] = 'year';
            $formatRE .= '(\\d\\d)';
            $format = $1;
# print "   <year>...\n";
            }
        elsif ($format =~ /^%Y(.*)/)            # year as ccyy
            {
            $$parensTypesRef[$parensIdx++] = 'year';
            $formatRE .= '([12]\\d\\d\\d)';
            $format = $1;
# print "   <year>...\n";
            }
        elsif ($format =~ /^%m(.*)/)            # month of year
            {
            $$parensTypesRef[$parensIdx++] = 'month';
            $formatRE .= '([01]\\d)';
            $format = $1;
# print "   <month>...\n";
            }
        elsif ($format =~ /^%[bBh](.*)/)        # month name
            {
            $$parensTypesRef[$parensIdx++] = 'monthName';
            $formatRE .= '([a-zA-Z]+)';
            $format = $1;
# print "   <monthName>...\n";
            }
        elsif ($format =~ /^%j(.*)/)            # day of year
            {
            $$parensTypesRef[$parensIdx++] = 'dayOfYear';
            $formatRE .= '([0-3]\\d\\d)';
            $format = $1;
# print "   <dayOfYear>...\n";
            }
        elsif ($format =~ /^%d(.*)/)            # day of month
            {
            $$parensTypesRef[$parensIdx++] = 'day';
            $formatRE .= '([0-3]\\d)';
            $format = $1;
# print "   <day>...\n";
            }
        elsif ($format =~ /^%e(.*)/)            # day of month
            {
            $$parensTypesRef[$parensIdx++] = 'day';
            $formatRE .= '([\\s1-3]\\d)';
            $format = $1;
# print "   <day>...\n";
            }
        elsif ($format =~ /^%[aA](.*)/)         # weekday name
            {
            $$parensTypesRef[$parensIdx++] = 'weekdayName';
            $formatRE .= '([a-zA-Z]+)';
            $format = $1;
# print "   <weekdayName>...\n";
            }
        elsif ($format =~ /^%[UW](.*)/)         # week of year
            {
            $$parensTypesRef[$parensIdx++] = 'weekOfYear';
            $formatRE .= '([0-5]\\d)';
            $format = $1;
# print "   <weekOfYear>...\n";
            }
        elsif ($format =~ /^%w(.*)/)            # day of week
            {
            $$parensTypesRef[$parensIdx++] = 'dayOfWeek';
            $formatRE .= '([0-6])';
            $format = $1;
# print "   <dayOfWeek>...\n";
            }
        elsif ($format =~ /^%H(.*)/)            # hour
            {
            $$parensTypesRef[$parensIdx++] = 'hour';
            $formatRE .= '([0-2]\\d)';
            $format = $1;
# print "   <hour>...\n";
            }
        elsif ($format =~ /^%I(.*)/)            # hour (12-hour cycle)
            {
            $$parensTypesRef[$parensIdx++] = 'hour12';
            $formatRE .= '([01]\\d)';
            $format = $1;
# print "   <hour12>...\n";
            }
        elsif ($format =~ /^%p(.*)/)            # ante-/post-meridiem
            {
            $$parensTypesRef[$parensIdx++] = 'meridiem';
            $formatRE .= '([aApP][mM])';
            $format = $1;
# print "   <meridiem>...\n";
            }
        elsif ($format =~ /^%M(.*)/)            # minute
            {
            $$parensTypesRef[$parensIdx++] = 'minute';
            $formatRE .= '([0-5]\\d)';
            $format = $1;
# print "   <minute>...\n";
            }
        elsif ($format =~ /^%S(.*)/)            # second
            {
            $$parensTypesRef[$parensIdx++] = 'second';
            $formatRE .= '([0-6]\\d)';
            $format = $1;
# print "   <second>...\n";
            }
        elsif ($format =~ /^%Z(.*)/)            # time zone
            {
            $$parensTypesRef[$parensIdx++] = 'timeZone';
            $formatRE .= '([A-Z]+)';
            $format = $1;
# print "   <timeZone>...\n";
            }

        elsif ($format =~ /^%c(.*)/)            # country-spec date/time format
            {
            $format = "%a %b %d %H:%M:%S %Y$1";
            }
        elsif ($format =~ /^%[Dx](.*)/)         # date as %m/%d/%y (%D)
            {                                   # country-spec date format (%x)
            $format = "%m/%d/%y$1";
            }
        elsif ($format =~ /^%r(.*)/)            # time as %I:%M:%S %p
            {
            $format = "%I:%M:%S %p$1";
            }
        elsif ($format =~ /^%R(.*)/)            # time as %H:%M
            {
            $format = "%H:%M$1";
            }
        elsif ($format =~ /^%[TX](.*)/)         # time as %H:%M:%S (%T)
            {                                   # country-spec time format (%X)
            $format = "%H:%M:%S$1";
            }

        elsif ($format =~ /^%(.)(.*)/)          # some other % character
            {
            $formatRE .= &protectChars($1);
            $format = $2;
# print "   <percent stuff>...\n";
            }
        # else { last; }
        }

    $formatRE;
    }


#
# protectChars()
#
# $str = &protectChars($str);
#
# Return a copy of $str such that all characters in it that are in the list
# '$()*+,.?[\\]^{|}' are preceded with a backslash character.
#
sub protectChars
    {
    my ($str) = @_;     # the string of characters to protect

    join('',
         map(((index('$()*+,.?[\\]^{|}', $_) >= 0)? "\\$_" : $_),
             split('', $str)));
    }


#
# computeCTime
#
# $time = &computeCTime($offset, \@parensTypes, @matches);
#
# A date/time string matched against a format regular expression:  $parensTypes
# is a reference to the array that describes the types of the fields of that
# format/regular expression, and @matches is the corresponding array of
# broken-out substrings of the matched date/time string.  Compute a C epoch
# time (in GMT) from these pieces.  If any piece is missing, a suitable default
# value is used for it.
#
# If one of the fields is a time zone field, and its corresponding substring is
# a recognized time zone, the offset for that time zone is used to adjust the
# computed time to make it in GMT.  Otherwise if $offset is defined and nonzero,
# it is used (by simple addition) for this purpose.
#
# If such a time could be computed, it is returned.  Otherwise the return
# value is one of:
#       -1  --  bad month name  --  the (abbreviated or full) month name value
#                   is not a recognized one
#       -2  --  bad time zone  --  the time zone value is not a recognized one
#       -3  --  bad day of the year  --  the Julian day is out of range
#
sub computeCTime
    {
    my ($offset,            # time zone offset
        $parensTypesRef,    # reference to types of matching parens array
        @matches) = @_;     # the matching values
    my ($type,              # alias for $$parensTypesRef[$i]
        $value,             # alias for $matches[$i]
        $year,              # the value for the year
        $month,             # the value for the month
        $dayOfMonth,        # the value for the day of the month
        $hour,              # the value for the hours
        $minute,            # the value for the minute
        $second,            # the value for the second
        $dayOfYear,         # the value for the day of the year
        $pmOffset,          # the offset for post-meridiem
        $i);                # index counter

# splice(@matches, @$parensTypesRef);
# print '   @matches = ("', join('", "', @matches), "\")\n";
    $offset = 0 if (!defined($offset));
    $year = $month = $hour = $minute = $second = 0;
    $dayOfMonth = 1;
    $dayOfYear = -1;
    $pmOffset = 0;
    for ($i = 0;  $i < @$parensTypesRef;  ++$i)
        {
        $type = $$parensTypesRef[$i];
        $value = $matches[$i];
        if ($type eq 'year')
            {
            if (length($value) <= 2)
                {
                $year = ($value < 70)? $value + 100 : $value;
                }
            else
                {
                $year = $value - 1900;
                }
            }
        elsif ($type eq 'month')
            {
            $month = $value - 1;        # convert from 1..12 to 0..11
            }
        elsif ($type eq 'monthName')
            {
            $month = &monthNameToNumber($value);
            return (-1) if ($month < 0);
            }
        elsif ($type eq 'dayOfYear')
            {
            $dayOfYear = $value;        # true computation done below
            }
        elsif ($type eq 'day')
            {
            $dayOfMonth = $value;
            }
        elsif ($type eq 'hour')
            {
            $hour = $value;
            }
        elsif ($type eq 'hour12')
            {
            $hour = ($value == 12)? 0 : $value;
            }
        elsif ($type eq 'meridiem')
            {
            $pmOffset = 43200 if ($value =~ /[pP]/);    # 12-hour pm offset
            }
        elsif ($type eq 'minute')
            {
            $minute = $value;
            }
        elsif ($type eq 'second')
            {
            $second = $value;
            }
        elsif ($type eq 'timeZone')
            {
            $offset = &timeZoneToOffset($value);
            return (-2) if (!defined($offset));
            }
        }
    if ($dayOfYear >= 0)
        {
        ($month, $dayOfMonth) = &jdayToMonthDay($dayOfYear, $year);
        return (-3) if (!defined($month));
        }
# print "\$year = $year\n";
# print "\$month = $month\n";
# print "\$dayOfMonth = $dayOfMonth\n";
# print "\$hour = $hour\n";
# print "\$minute = $minute\n";
# print "\$second = $second\n";
# print "\$pmOffset = $pmOffset\n";
# print "\$offset = $offset\n";
    &timegm($second, $minute, $hour, $dayOfMonth, $month, $year)
      + $pmOffset + $offset;
    }


#
# timeToTimeStr()
#
# $timeStr = &timeToTimeStr($time, $format);
#
# Convert the time value $time to a string based on the format string $format.
#
# Recognized field descriptors:
#   %a -- abbreviated weekday name ('C' locale only)
#   %A -- full weekday name ('C' locale only)
#   %b -- abbreviated month name ('C' locale only)
#   %B -- full month name ('C' locale only)
#   %c -- date/time as %a %b %d %H:%M:%S %Y ('C' locale only)
#   %d -- day of month (01 to 31)
#   %D -- date as %m/%d/%y
#   %e -- day of month (1 to 31)
#   %h -- abbreviated month name (alias for %b)
#   %H -- hour (00 to 23)
#   %I -- hour (01 to 12)
#   %j -- day of year (001 to 366)
#   %m -- month of year (01 to 12)
#   %M -- minute (00 to 59)
#   %n -- newline character
#   %p -- ante-/post-meridiem indicator ('C' locale)
#   %r -- time as %I:%M:%S %p
#   %R -- time as %H:%M
#   %S -- second (00 to 61)
#   %t -- tab character
#   %T -- time as %H:%M:%S
#   %w -- day of week (Sunday = 0)
#   %x -- date as %m/%d/%y ('C' locale only)
#   %X -- time as %H:%M:%S ('C' locale only)
#   %y -- year within century (00 to 99)
#   %Y -- year as ccyy (4 digits)
#   %Z -- timezone name ('GMT' only)
#   %% -- percent character
#
# Unrecognized field descriptors:
#   %U -- week number of year (00 to 53) (Sunday) (prints as itself)
#   %W -- week number of year (00 to 53) (Monday) (prints as itself)
#
# And:
#   <anything else> -- itself
#
# 'C' or 'English' locale is assumed.  This affects the interpretation of the
# %c, %p, %x, and %X field descriptors, as well as the day and month names.
# Also note that only GMT is current supported.
#
sub timeToTimeStr
    {
    my ($time, $format) = @_;
    my ($timeStr,           # $time converted into a string
        $year,              # the value for the year
        $month,             # the value for the month
        $day,               # the value for the day of the month
        $hour,              # the value for the hours
        $minute,            # the value for the minute
        $second,            # the value for the second
        $dayOfWeek,         # the value for the day of the week
        $dayOfYear);        # the value for the day of the year

    ($second, $minute, $hour, $day, $month, $year, $dayOfWeek, $dayOfYear)
      = gmtime($time);
    $timeStr = '';
    while ($format)
        {
        if ($format =~ /^([^%]+)(.*)/)          # not a field directive substr
            {
            $timeStr .= $1;
            $format = $2;
            }
        elsif ($format =~ /^%y(.*)/)            # year within century
            {
            $timeStr .= sprintf("%02d", $year % 100);
            $format = $1;
            }
        elsif ($format =~ /^%Y(.*)/)            # year as ccyy
            {
            $timeStr .= sprintf("%02d", $year + 1900);
            $format = $1;
            }
        elsif ($format =~ /^%m(.*)/)            # month of year
            {
            $timeStr .= sprintf("%02d", $month + 1);
            $format = $1;
            }
        elsif ($format =~ /^%[bh](.*)/)         # abbreviated month name
            {
            $timeStr .= ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                         'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')[$month];
            $format = $1;
            }
        elsif ($format =~ /^%B(.*)/)            # full month name
            {
            $timeStr .= ('January', 'February', 'March',
                         'April',   'May',      'June',
                         'July',    'August',   'September',
                         'October', 'November', 'December')[$month];
            $format = $1;
            }
        elsif ($format =~ /^%j(.*)/)            # day of year
            {
            $timeStr .= sprintf("%03d", $dayOfYear + 1);
            $format = $1;
            }
        elsif ($format =~ /^%([de])(.*)/)       # day of month
            {
            $timeStr .= sprintf(($1 eq 'd')? '%02d' : '%2d', $day);
            $format = $2;
            }
        elsif ($format =~ /^%a(.*)/)            # abbreviated weekday name
            {
            $timeStr .= ('Sun', 'Mon', 'Tue', 'Wed',
                         'Thu', 'Fri', 'Sat')[$dayOfWeek];
            $format = $1;
            }
        elsif ($format =~ /^%A(.*)/)            # full weekday name
            {
            $timeStr .= ('Sunday', 'Monday', 'Tuesday', 'Wednesday',
                         'Thusday', 'Friday', 'Saturday')[$dayOfWeek];
            $format = $1;
            }
        elsif ($format =~ /^%w(.*)/)            # day of week
            {
            $timeStr .= sprintf('%d', $dayOfWeek);
            $format = $1;
            }
        elsif ($format =~ /^%H(.*)/)            # hour
            {
            $timeStr .= sprintf('%02d', $hour);
            $format = $1;
            }
        elsif ($format =~ /^%I(.*)/)            # hour (12-hour cycle)
            {
            if (($hour == 0) || ($hour == 12))
                {
                $timeStr .= '12';
                }
            else
                {
                $timeStr .= sprintf('%02d', $hour % 12);
                }
            $format = $1;
            }
        elsif ($format =~ /^%p(.*)/)            # ante-/post-meridiem
            {
            $timeStr .= ($hour >= 12)? 'PM' : 'AM';
            $format = $1;
            }
        elsif ($format =~ /^%M(.*)/)            # minute
            {
            $timeStr .= sprintf('%02d', $minute);
            $format = $1;
            }
        elsif ($format =~ /^%S(.*)/)            # second
            {
            $timeStr .= sprintf('%02d', $second);
            $format = $1;
            }
        elsif ($format =~ /^%Z(.*)/)            # time zone
            {
            $timeStr .= 'GMT';
            $format = $1;
            }

        elsif ($format =~ /^%c(.*)/)            # country-spec date/time format
            {
            $format = "%a %b %d %H:%M:%S %Y$1";
            }
        elsif ($format =~ /^%[Dx](.*)/)         # date as %m/%d/%y (%D)
            {                                   # country-spec date format (%x)
            $format = "%m/%d/%y$1";
            }
        elsif ($format =~ /^%r(.*)/)            # time as %I:%M:%S %p
            {
            $format = "%I:%M:%S %p$1";
            }
        elsif ($format =~ /^%R(.*)/)            # time as %H:%M
            {
            $format = "%H:%M$1";
            }
        elsif ($format =~ /^%[TX](.*)/)         # time as %H:%M:%S (%T)
            {                                   # country-spec time format (%X)
            $format = "%H:%M:%S$1";
            }

        elsif ($format =~ /^%%(.*)/)            # percent
            {
            $timeStr .= '%';
            $format = $1;
            }
        elsif ($format =~ /^%n(.*)/)            # newline
            {
            $timeStr .= "\n";
            $format = $1;
            }
        elsif ($format =~ /^%t(.*)/)            # tab
            {
            $timeStr .= "\t";
            $format = $1;
            }

        elsif ($format =~ /^(%.)(.*)/)          # unsupported stuff
            {
            $timeStr .= $1;
            $format = $2;
            }
        # else { last; }
        }

    $timeStr;
    }


#
# monthNameToNumber
#
# $month = &monthNameToNumber($monthName)
#
# Convert the month name $monthName to its month number (in the range 0..11).
# -1 is returned if $monthName can not be recognized.
#
# monthNameToNumber() only understands 'C' locale names and abbreviations,
# although we attempt to handle some obscure abbreviations (well, this isn't
# true, yet).
#
sub monthNameToNumber
    {
    my ($monthName) = @_;   # the name (abbreviated) of the month

    @monthNames = ( 'january',   'february', 'march',    'april',
                    'may',       'june',     'july',     'august',
                    'september', 'october',  'november', 'december' )
      if (!@monthNames);
    $monthName = lc($monthName);
    for ($i = 0;  $i < 12;  ++$i)
        {
        return ($i) if ($monthNames[$i] =~ /^$monthName/);
        }
    -1;
    }


#
# jdayToMonthDay()
#
# ($month, $day) = &jdayToMonthDay($jday, $year);
#
# Convert the Julian day $jday (for the year $year) into its equivalent month
# and day values.  The month value is in the range 0..11.
#
sub jdayToMonthDay
    {
    my ($jday, $year) = @_;
    my (@days, $i);

    @days = (($year % 4) == 0)?
        (0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366)
      : (0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365);

    for ($i = 0;  $i < 12;  ++$i)
        {
        return ($i, $jday - $days[$i]) if ($jday <= $days[$i+1]);
        }
    ();
    }


#
# timeZoneToOffset()
#
# $offset = &timeZoneToOffset($timeZone);
#
sub timeZoneToOffset
    {
    my ($timeZone) = @_;

# print "\$timeZone = $timeZone\n";
    %tzHash = (
        'NZDT',   -46800,                                       # -13 hours
        'NZST',   -43200,                                       # -12 hours
        'SADT',   -10800,                                       # -3 hours
        'METDST',  -7200,  'MESZ', -7200, 'SAST',   -7200,      # -2 hours
        'BST',     -3600,  'MET',  -3600, 'MEZ',    -3600,      # -1 hour
                           'PST',  -3600, 'WETDST', -3600,
        'GMT',         0,  'PWT',      0, 'UTC',        0,      # 0 hours
                           'WET',      0,
        'NDT',      9000,                                       # +2.5 hours
        'ADT',     10800,                                       # +3 hours
        'NST',     12600,                                       # +3.5 hours
        'AST',     14400,  'EDT',  14400,                       # +4 hours
        'CDT',     18000,  'EST',  18000,                       # +5 hours
        'CST',     21600,  'MDT',  21600,                       # +6 hours
        'MST',     25200,  'PDT',  25200,                       # +7 hours
        'PST',     28800,  'YDT',  28800,                       # +8 hours
        'YST',     32400 )                                      # +9 hours
      if (!%tzHash);
# print "\$timeZone = $timeZone\n";
    $tzHash{$timeZone};
    }

1;
