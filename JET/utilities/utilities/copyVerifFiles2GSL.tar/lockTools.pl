#! /usr/local/bin/perl
#! /usr/local/bin/perl -w
#-----------------------------------------------------------------------------
#  NOAA/ERL
#  Forecast Systems Laboratory
#  Facility Division
#  Central Facility Management Branch
#  NIMBUS Software
#
#  This software and its documentation are in the public domain and are
#  furnished "as is".  The United States Government, its instrumentalities,
#  officers, employees, and agents make no warranty, express or implied, as to
#  the usefulness of the software and documentation for any purpose.  They
#  assume no responsibility (1) for the use of the software and documentation;
#  or (2) to provide technical support to users.
#
#  lockTools.pl  --  advisory file locking tools.
#
#  WARNING:  this is OPAQUE Facility Division (FD) software.  All OPAQUE FD
#  software is subject to change without notice.
#
#  Glen Pankow      29 Apr 98       1.1     Original version.
#  Glen Pankow       9 Oct 98       1.2     Now checks for EWOULDBLOCK errors.
#
#  07/22/04   Bob Lipschutz      Replace flock w/ fcntl
#-----------------------------------------------------------------------------
#  $Id: lockTools.pl,v 1.3 2004/07/22 19:21:17 lipschut Exp $

use Fcntl;

#
# LockFile()
#
# $retcode = &LockFile(\*file, $readWrite, $maxWaitSeconds);
# $retcode = &LockFile(\*file, $readWrite);
# $retcode = &LockFile(\*file);
#
# Lock the file whose reference is given by $file.  If $readWrite is not
# defined or if it is defined and nonzero, an exclusive advisory lock is used,
# otherwise a shared lock is used.  If $maxWaitSeconds is defined and is
# positive, at most that many seconds are allowed to elapse before this routine
# gives up trying to lock the file, otherwise this routine blocks indefinitely
# until the lock succeeds.
#
# $file should have been just opened (i.e., no operations on the file should
# have been performed on it yet).
#
# If the lock is successful, 1 is returned, 0 otherwise, in which case $!
# describes the error.
#
sub LockFile
    {
    my ($fh,                    # handle to the file to lock
        $readWrite,             # exclusive lock?
        $maxWaitSeconds) = @_;  # number of seconds after which we give up
    my ($lockMode,              # lock mode code
        $errorCode);            # save copy of the error code (int($!))

    $readWrite = 1 unless (defined($readWrite));
    $lockMode = $readWrite? F_WRLCK : F_RDLCK;

    my @fcntl_args = ($lockMode, SEEK_SET, 0,1,0);
    my $fcntl_args = pack("sslli", @fcntl_args);  # 2 shorts, 2 longs, 1 int

        #struct flock lock:
        #lock.l_type = F_WRLCK;
        #lock.l_whence = $SEEK_SET;
        #lock.l_start = offset;
        #lock.l_len = len;
        #lock.l_pid = 0;
    #
    # If $maxWaitSeconds is not specified or it is specified but it is zero
    # or negative, we interpret that to mean that the user wishes to have this
    # routine block indefinitely until the file becomes unlocked.
    #
    if (!defined($maxWaitSeconds) || ($maxWaitSeconds <= 0))
        {
        return (1) if ( fcntl($fh, F_SETLKW, $fcntl_args) );
	$errorCode = int($!);
	$! = $errorCode;
	
	return 0;
        }

    #
    # Otherwise, we'll keep trying to lock the file until either the lock
    # succeeds or we've waited the maximum time.
    #
    for (;  $maxWaitSeconds > 0;  --$maxWaitSeconds)
        {
        return (1) if ( fcntl($fh, F_SETLK, $fcntl_args) );
        $errorCode = int($!);

        sleep(1);
        }
    $! = $errorCode;
    0;
    }


#
# UnlockFile()
#
# $retcode = &UnlockFile(\*file);
#
# Unlock the file previously locked by LockFile().  1 is returned if
# successful, 0 otherwise, in which case $! describes the error.
#
sub UnlockFile
    {
    my ($fh) = @_;

    my @fcntl_args = (F_UNLCK, SEEK_SET, 0,1,0);
    my $fcntl_args = pack("sslli", @fcntl_args);  # 2 shorts, 2 longs, 1 int

    return (1) if ( fcntl($fh, F_SETLK, $fcntl_args) );
    $errorCode = int($!);
    $! = $errorCode;
	
    return 0;
    }

1;

__END__

$file = "/home/lipschut/test/data/.tmp/prevRetrStatus";

for ($i=0; $i<3; $i++)
{

open(FILE, "+>> $file")
    || die "$0:  could not create the file $file:  $!.  Aborting.\n";

print "Wait for lock on $file\n";
$lock = LockFile(\*FILE, 1, 30);   # exclusive

if ($lock)
    {
    print "Acquired lock - sleep 10\n";
    print FILE "Acquired lock - sleep 10\n";
    sleep (10);
    UnlockFile(\*FILE);
    print "Released lock\n";
    print FILE "Released lock\n";

    }
else
    {
    print "Could not get lock... $!\n";
    }
$sleep = int(rand(8)+1);
print "$$ sleeping $sleep sec\n";
sleep $sleep;
}
print "done\n";


__END__

#
# Below are some tests (Glen's original tests).  
# Try to run several runs of this script simultaneously.
# Start them about two seconds apart.
#

$now = time();
$myNum = $now % 10;
srand($now | $$);
sleep(5);

for ($i = 0;  $i < 3;  ++$i)
    {
    $nowStr = &formatTime($myNum, $now = time());
    print "$nowStr:  calling addLines()...\n";
    addLines();
    $sleepSeconds = between(0, 10);
    sleep($sleepSeconds);
    $nowStr = &formatTime($myNum, $now = time());
    print "$nowStr:  slept for $sleepSeconds seconds.\n";
    }

$nowStr = &formatTime($myNum, $now = time());
print "$nowStr:  ALL DONE!\n";


#
# addLines();
#
# Write some lines to the data file once it's been locked.  The lines are
# also written to STDOUT.
#
sub addLines
    {
    my ($start, $startStr,
        $now, $nowStr,
        $maxWaitSeconds,
        $diffSeconds,
        $sleepSeconds);

    $startStr = &formatTime($myNum, $start = time());
    open(FILE, "+>> $0.out")
      || die "$0:  could not create the file '$0.dat':  $!.  Aborting.\n";
    $maxWaitSeconds = between(-10, 3);
    print "$startStr:  calling \&LockFile(\\*FILE, 1, $maxWaitSeconds)...\n";
    if (!LockFile(\*FILE, 1, $maxWaitSeconds))
        {
        if (int($!) == $EWOULDBLOCK)
            {
            print "$startStr:  \&LockFile() failed with EWOULDBLOCK...\n";
            }
        else
            {
            print "$startStr:  \&LockFile() failed with $!.\n";
            }
        close(FILE);
        return;
        }
    $nowStr = &formatTime($myNum, $now = time());
    $diffSeconds = $now - $start;
    print "$nowStr:  I had to wait $diffSeconds seconds.\n";
    $sleepSeconds = between(0, 10);
    print "$nowStr:  will now sleep for $sleepSeconds seconds.\n";
    sleep($sleepSeconds);
    $nowStr = &formatTime($myNum, $now = time());
    print "$nowStr:  calling \&UnlockFile(\\*FILE)\n";

    print FILE
      "$startStr:  calling \&LockFile(\\*FILE, 1, $maxWaitSeconds)...\n";
    print FILE "$nowStr:  I had to wait $diffSeconds seconds.\n";
    print FILE "$nowStr:  will now sleep for $sleepSeconds seconds.\n";
    print FILE "$nowStr:  calling \&UnlockFile(\\*FILE)\n";
    &UnlockFile(\*FILE);
    close(FILE);
    return;
    }


sub formatTime
    {
    my ($num) = shift(@_);
    my ($time) = $_[0] || time();
    my ($sec, $hour, $min);

    ($sec, $min, $hour) = gmtime($time);
    sprintf("%s:  %02d:%02d:%02d", $num, $hour, $min, $sec);
    }


#
# between()
#
# $randValue = &between($low, $high);
#
# Return a random integer value between $low and $high, inclusive.
#
sub between
    {
    my ($low, $high) = @_;

    int(rand() * ($high - $low + 1) + $low);
    }
