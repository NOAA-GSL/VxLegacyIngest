#! /usr/bin/perl 
#-----------------------------------------------------------------------------
#  NOAA Global Systems Laboratory
#  Information and Technology Services
#  Data Services Group
#
# copyVerifFiles2GSL.pl  --  transfers AVID verification files via globus-url-copy to GSL's Incoming Data Transfer Gateway (dtgi)
#
#  Usage:
#      copyVerifFiles2GSL.pl -sourceDir <source dir> [ -logDir <logDir> ]
#  where:
#      -logDir <logDir>   --  the directory into which log files are written.  If not
#          specified, logging is written to stdout/stderr.
#
#  This software and its documentation are in the public domain and are
#  furnished "as is".  The United States Government, its instrumentalities,
#  officers, employees, and agents make no warranty, express or implied, as to
#  the usefulness of the software and documentation for any purpose.  They
#  assume no responsibility (1) for the use of the software and documentation;
#  or (2) to provide technical support to users.
#
#  04/12/21  Bob Lipschutz	Original version, derived from DSG's embGraphicsCopy.pl and newFileGlobusCopy.pl
#-----------------------------------------------------------------------------
#  $Header: /home/Role.Rtoper/scripts/RCS/copyVerifFiles2GSL.pl,v 1.1 2021/04/12 21:57:54 Role.Rtoper Exp Role.Rtoper $

use File::Basename;
$binDir = dirname($0);
$hostname = `/bin/hostname`; 
chop $hostname; 
$Process   = "copyVerifFiles2GSL"; 

BEGIN { unshift(@INC, "$ENV{'HOME'}/scripts", $binDir); } 
use Time::localtime; 
require 'fnameLib.pl'; 
require 'fileNameTimeTools.pl';
require 'lockTools.pl';
require 'logTools.pl';

$ENV{'PATH'} = "$ENV{'HOME'}/bin:$ENV{'HOME'}/scripts:$ENV{'PATH'}";

# These dirs are where the state, lock and 'list' files are put
$LockDir  = "$ENV{'HOME'}/.$Process/lockfiles";
$ListDir  = "$ENV{'HOME'}/.$Process/listfiles";
$StateDir = "$ENV{'HOME'}/.$Process/statefiles";

$StateFileMaxAge_min = 7200;   # Remove state files older than 5 days  (probably not an issue for verif dir)
$LockFileMaxAge_min =  30;     # Remove log files after this many minutes
$SettleAge = 5;                # Consider files 'settled' (ready to xfer) after 5 seconds

#  globus-url-copy is our transfer client utility, which is able to talk to talk to GSL's incoming data transfer gateway (dtgi)
#    Use '-cc <n>' to specify number of concurrent files to copy.
#    Use '-p <n>' to specify number of parallel threads per file.
#    Not sure what the other args do, but they work... :-)  Note that '-data-cred auto' is required.
$GlobusUrlCopy = "globus-url-copy -data-cred auto -fast -bs 1M -tcp-bs 16M -pp -cc 8 -p 1 -dcsafe";

# Where we push the files to, in globus-url-copy syntax
#   NOTE: authentication is via ssh keys held by user 'gwmover' on dtgi
$DestHost = "sshftp://gwmover\@dtgi.gsd.esrl.noaa.gov";    
$DestDir = "/hpc-verif";       # Transferred files will land here in qumulo space mounted on dtgi,

#$SourceFileGlob = "*";      # Use this to xfer all files in source dir
$SourceFileGlob = "DD:*";      # Hard coded for AVID Couchbase verification file names

$start_time=time;

umask(0022);

$usage = "Usage: copyVerifFiles2GSL.pl -sourceDir <sourceDir> [-logDir <logDir>]";

#------------------------------------------------------------------
# Process the command-line arguments.
#------------------------------------------------------------------
for ($i = 0;  $i < @ARGV;  ++$i)
    {
    $lcArg = lc($ARGV[$i]);
    $lcArgLen = length($lcArg);
    if (substr('-logdirectory', 0, $lcArgLen) eq $lcArg)
        {
        $LogDir = $ARGV[++$i];
        }
    elsif (substr('-sourcedir', 0, $lcArgLen) eq $lcArg)
        {
        $SourceDir = $ARGV[++$i];
        }
    else
        {
        print STDERR
            "$0:  ignoring the unrecognized command-line argument '$ARGV[$i]'.\n";
        print STDERR "$usage\n";

        }
    }

unless (defined($SourceDir))
    {
    print STDERR
        "$0:  the source directory was not specified on the command line.",
        "  Aborting.\n";
    print STDERR "$usage\n";
    exit(1); 
    }

&LogFileOpen($LogDir) if (defined($LogDir));
printf "\n$Process started  --  %s GMT  --\n",scalar(gmtime($start_time));

&LogMessages(undef, "\$ListDir = '$ListDir'");
&LogMessages(undef, "\$LockDir = '$LockDir'");
&LogMessages(undef, "\$StateDir = '$StateDir'");

# Before we start, purge older state/list/lock files, create dirs if necessary
&cleanupProcessFiles();

#------------------------------------------------------------------
# Set interrupt handler
#------------------------------------------------------------------
$Interrupted = 0;		# interrupted by a signal?
$SIG{'TERM'} = $SIG{'INT'} = $SIG{'QUIT'} = $SIG{'HUP'} = 'interrupt';


#------------------------------------------------------------------
# Set the lock file
#------------------------------------------------------------------
$srcStr = &pathToDottedPath($SourceDir);
$lockFile = "$LockDir/$srcStr.lock"; 
&LogMessages(" Setting lock file $lockFile ");
open  LOCK, ">>$lockFile" or die "Cannot open lock file $lockFile: $!";
$haveLock = &LockFile(\*LOCK, 1, 10);
die "Can't get lock for $lockFile (job must already be running), so exiting..." if $haveLock != 1;

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = gmtime($start_time);
$datetime = sprintf("%04d%02d%02d%02d%02d%02d", $year + 1900, $mon+1, $mday, $hour, $min, $sec );
($h = $ENV{'HOST'}) =~ s/(\w*)\..*/$1/;

truncate(LOCK,0);
print LOCK "$datetime | $h | $0 @ARGV\n";

#------------------------------------------------------------------
# Process the specified directory
#------------------------------------------------------------------
$NumFiles = 0;
$NumBytes = 0;

&processDir($SourceDir);

print "\n";
&LogMessages(">> $Process done.   $NumFiles files copied.");

$end_time=time;
$diff_time = $end_time - $start_time;

if ($NumBytes > 0 && $diff_time > 0)
    {
    $xferRate = $NumBytes / $diff_time / 1000000;
    &LogMessages("Avg xfer rate: $xferRate MB/s"); 
    }

printf "\n%s: completed  --  %s GMT  --\n", $Process, scalar(gmtime($end_time));
printf "%s: Elapsed time:  %d minutes, %d seconds\n", $Process,
                ($diff_time % 3600) / 60, $diff_time % 60;

printf LOCK "%s: completed in %d sec -- %s GMT --\n", $0, $diff_time, scalar(gmtime($end_time));
&UnlockFile(\*LOCK); 
close LOCK;

exit(0);


#------------------------------------------------------------------
# processDir()
#
# Files with ctimes within $SettleAge seconds are not processed
# to avoid handling files that might be updated.  
#
#------------------------------------------------------------------
sub processDir
    {
    my ($sourceDir) = @_;       # the path to the dir of graphics files to transfer

    my ($dirStr,                # $dir in dotted string form
	$lastFile,		# the name of the last batch file successfully handled
	$lastCTime,		# its last ctime
	$file, 		        # a file
        $ctime,                 # file ctime
	$size,		        # file size
	@fileList);             # the full list of files matching the glob pattern

    $now = time();

    $dirStr = &pathToDottedPath($sourceDir);

    print "\n";
    print "   \$sourceDir = $sourceDir\n";

    #--------------------------------------------------------------
    # The last time this script processed files from the specified
    # directory, it kept track of the latest file time (either ctime
    # or fileNameTime) of the last file copied and wrote it to the  
    # data file for this directory.  Read that back in.
    #--------------------------------------------------------------
    $lastFile = '-';
    $lastCTime = 0;

    if (open(DAT, "$StateDir/$dirStr"))
        {
	while (<DAT>)
  	    {
	    next unless (/^\s*(\S+)\s+(\d+)/);
	    $lastFile  = $1;
	    $lastCTime = $2;
	    }
	close(DAT);
        }

    $newLastCTime = $lastCTime;

    #--------------------------------------------------------------
    # Get the list of files to consider 
    #--------------------------------------------------------------
    $fileString = "$sourceDir/$SourceFileGlob";

    print "   \$fileString is $fileString\n";
    print "   looking for files with ctime newer than $lastCTime\n";

    @fileList = glob ("$fileString");

#    print ("fileList is @fileList\n");

    $NumFilesForDir = 0;
    %CTimes = ( );
    %Sizes = ( );

    #--------------------------------------------------------------
    # Loop through files in directory, build list of file ctimes
    #--------------------------------------------------------------
    foreach $file (@fileList)
        {
#	print "checking $file\n";

        ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks)
            = stat($file);

	#--------------------------------------------------------------
	# Ignore any files that have ctimes earlier than the latest known 
	# processed file, and ignore those that have yet to settle.
	#--------------------------------------------------------------
	next unless -f _;		        # ignore non-regular files
	next unless $size > 0;	                # ignore empty files

#	 print "file is $file   size is $size   ctime is $ctime\n";

	if ($ctime + $settleAge >= $now)        # ignore unsettled files using ctime
	    {
  	    $x = $settleAge - ($now - $ctime);
	    print "++++ '$file' needs still to settle ($x seconds left) ++++\n";
	    next;
	    }

	if ($ctime <= $lastCTime)	    # ignore old files
  	    {
	    next;
	    }
	else
	    {
  	    #   print "using $file   $ctime $lastCTime   $lastFile \n";
	    }

	# Have a file to process
	$CTimes{$file} = $ctime;
	$Sizes{$file} = $size;

	# Capture the latest filename & ctime for our state file
	if ($ctime > $newLastCTime)
	    {
	    $newLastCTime = $ctime;
	    $lastFile = $file;
	    }

	$NumFiles++;
	$NumFilesForDir++;
        }

    return 1 if ($NumFilesForDir == 0);		# no new files?

    #--------------------------------------------------------------
    # Open the list file that globus-url-copy will use
    #--------------------------------------------------------------
    if (open(LIST, "> $ListDir/$dirStr"))
        {
	print "   Opened List File: $ListDir/$dirStr\n";
        }
    else
        {
	&LogMessages("! could not write to the data file '$ListDir/$dirStr':"
		     . "  $!.  Ignoring this datum.");
        }

    #--------------------------------------------------------------
    # Loop through the files, and create the list
    #--------------------------------------------------------------
    foreach $file (sort(keys %CTimes))
        {
	$fname = basename $file;

	#----------------------------------------------------------
	# Add the source and destination URL for each file to transfer
	# to our list file
	#----------------------------------------------------------
	print LIST "file:$file $DestHost$DestDir/$fname\n";

	$NumBytes += $Sizes{$file};

	print "$file   size: $Sizes{$file}   ctime: $CTimes{$file}\n";
        }
    close LIST;

    print "  >> Transferring $NumFilesForDir files under $sourceDir\n\n";

    #--------------------------------------------------------------
    # Now do the deed -- transfer the files!
    #--------------------------------------------------------------
    $cmd = "system($GlobusUrlCopy -f $ListDir/$dirStr)";
    print "globus cmd:  $cmd\n";
    
    unless (system("$GlobusUrlCopy -f $ListDir/$dirStr") == 0)
        {
	print "*** system($cmd) failed: $?\n";
	return 1;
        }

    #--------------------------------------------------------------
    # Wrap up by saving info about last file processed
    #--------------------------------------------------------------
    if (open(DAT, "> $StateDir/$dirStr"))
        {
	print "\n   --- Updating state file $StateDir/$dirStr\n"; 
	print "           $lastFile $newLastCTime\n";
	print DAT "$lastFile $newLastCTime\n";
	close(DAT);
        }
    else
        {
	&LogMessages("! could not write to the data file '$StateDir/$dirStr':"
		     . "  $!.  Ignoring this datum.");
        }

    1;
    }

#------------------------------------------------------------------
# pathToDottedPath()
#    $dottedPath = &pathToDottedPath($path);
#
# Return a version of the path string $path with '/'s replaced by '.'s, with
# the leading '/', if any stripped.
#------------------------------------------------------------------
sub pathToDottedPath
        {
        my ($path) = @_;        # the normal path str to convert to a dotted path str

        $path = substr($path, 1) if ($path =~ m|^/|);   # strip leading '/', if any
        $path =~ tr|/|.|;                                                               # convert '/'s to '.'s
        $path;
        }


#------------------------------------------------------------------
# interrupt()
# Note an interrupt signal, set a flag for graceful exit.
#------------------------------------------------------------------
sub interrupt
	{
	$Interrupted = 1;

	&LogMessages("! Interrupted... bailing out");

	&UnlockFile(\*LOCK); 
	close LOCK;

	exit(1);

	}

#------------------------------------------------------------------
# interrupt()
# Note an interrupt signal, set a flag for graceful exit.
#------------------------------------------------------------------
sub cleanupProcessFiles
    {
    #--------------------------------------------------------------
    # Create our process file dirs, if necessary
    #--------------------------------------------------------------
    # process dir
    if (! -d dirname($LockDir))
        {
	if (! mkdir(dirname($LockDir), 0755))
            {
	    print "Can't create dir dirname($LockDir)\n";
	    exit 1;
            }
        }
    # LockDir
    if (! -d $LockDir)
        {
	if (! mkdir($LockDir, 0755))
            {
	    print "Can't create lock dir $LockDir\n";
	    exit 1;
            }
        }
    # ListDir
    if (! -d $ListDir)
        {
	if (! mkdir($ListDir, 0755))
            {
	    print "Can't create list dir $ListDir\n";
	    exit 1;
            }
        }
    # StateDir
    if (! -d $StateDir)
        {
	if (! mkdir($StateDir, 0755))
            {
	    print "Can't create state dir $StateDir\n";
	    exit 1;
            }
        }

    #--------------------------------------------------------------
    # Purge older files from process dirs... just do a simple find
    #--------------------------------------------------------------
    $cmd = "find $StateDir -maxdepth 1 -type f -mmin +$StateFileMaxAge_min -exec rm -f {} \\;";
#    print "$cmd\n";
    unless (system($cmd) == 0)
        {
        print "*** system($cmd) failed: $?\n";
        return 1;
        }

    $cmd = "find $ListDir -maxdepth 1 -type f -mmin +$StateFileMaxAge_min -exec rm -f {} \\;";
#    print "$cmd\n";
    unless (system($cmd) == 0)
        {
        print "*** system($cmd) failed: $?\n";
        return 1;
        }

    $cmd = "find $LockDir -maxdepth 1 -type f -mmin +$LockFileMaxAge_min -exec rm -f {} \\;";
#    print "$cmd\n";
    unless (system($cmd) == 0)
        {
        print "*** system($cmd) failed: $?\n";
        return 1;
        }
    }   
