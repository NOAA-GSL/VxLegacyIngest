#
#-----------------------------------------------------------------------------
#  NOAA/ESRL
#  Global Systems Division
#  Information and Tech Services
#  Data Systems Group
#
#  fileNameTimeTools.pl  --  routine for converting from NIMBUS file name times
#      to C epoch times.
#
#  This software and its documentation are in the public domain and are
#  furnished "as is".  The United States Government, its instrumentalities,
#  officers, employees, and agents make no warranty, express or implied, as to
#  the usefulness of the software and documentation for any purpose.  They
#  assume no responsibility (1) for the use of the software and documentation;
#  or (2) to provide technical support to users.
#
#  WARNING:  this is OPAQUE Facility Division (FD) software.  All OPAQUE FD
#  software is subject to change without notice.
#
#  O.K.  Doing the Y2K thingie showed that parsing file names with simple Perl 
#  regular expressions didn't quite work (many file names do not follow the
#  NIMBUS file naming conventions) due to ambiguities.  The checking can now be
#  explicitly done by considering which format to use for files of corresponding
#  directories.  But of course, now this stupid file may have to be updated
#  whenever a new directory containing non-NIMBUS-conventionalized file names
#  is added.
#
#  Note:  I wrote more generic time string conversion routines (extractDate),
#  but since there are not so many different formats to deal with now, for
#  efficiency I've just done the non-generic thing here.
#
#  These are the the known formats:
#     '^<yyjjjhhmm>'  --  regular NIMBUS format
#     '^<yyjjjhh>'  --  lapsmm5 raw format
#     '^<yyyyjjjhhmm>'  --  SSEC and HADS ASCII format
#     '^<yyyymmddhh>'  --  IIDA ASCII format
#     '^<yyyymmdd>'  --  NCEP VSDB format
#     '^<yyyymmddhhmm>'  --  AWC ASD format
#     '^<yyyymmdd_hh>'  --  LDAD Hydro/Mesonet format
#     '^<yyyymmdd_hhmm>'  --  RAP RCWF_NCWF format
#     '<yyyymmdd_hhmm>'  --  NEXRAD Level-II raw format
#     '^<yyyymmdd-hhmm>'  --  NSSL Radar Mosaic format
#     '^[EW]<yymmddhhmm>'  --  NESDIS satellite ASCII format
#     '^g\d+.<yyjjj>.<hhmm>'  --  NESDIS satellite binary format
#     '^\D*<yyyymmdd>_<hh>'  --  AWC grids ASCII format
#     '^\D*<yyyymmdd>.i<hh>'  --  RAP CeilVis format
#     '^\D*<yyyymmddhh>'  --  AWC grids GRIB format
#     '^\D*<yyyymmdd>'  --  precip data format
#     '^<yymmddhhmm>'  --  Alaska pireps format
#     '<yyyymmdd>_<hhmm>$'  --  AWC Satellite format
#     '<yyyymmdd>.<hhmm>'  --  pirep original format (1)
#     '<yyyymmdd>.<hh>'  --  pirep original format (2)
#     '<yyyymmdd>T<hhmm>'  --  MIT/LL SatCast
#     '<yyyymmddhh>'  --  stage4 precip format
#     '<yyyyjjjhhmm>'  --  generic 4-digit year + julian day
#     '<yyyyjjj_hhmm>'  --  generic 4-digit year + julian day
#     '<yyyyjjj.hhmm>'  --  NASA VISST format
#     '<yyyyjjj>'  --  FIRMS 
#     '<yymmdd\D\d_hhmm>'  --  AOML Radar Superobs
#     'none'  --  not time-based file names
#
#  Glen Pankow      01/05/00        ---     Original version.
#                   17/11/00        ---     More restrictive REs.
#                   08/17/00        ---     Added the precip data format.
#                   08/18/00        ---     Frthr checking what passes the REs.
#                   12/22/00        ---     Added the Alaska pirep format.
#                   09/07/00        ---     Added the AWC Satellite format.
#                   10/23/01        ---     Added the AWC GRIB format.
#                   02/04/02        ---     Added the pirep original formats.
#                   10/19/02        ---     Added the stage4 precip format.
#  Bob L.           11/01/02                Added the RAP CeilVis format.
#  Bob L.           08/31/04                Added the RAP RCWF_NCWF format.
#  Bob L.           04/10/06                Added the NSSL Radar Mosaic format
#  Bob L.           04/24/07                Added generic <yyjjjhhmm> pattern for 13kmruc/nssl_refl/tten_radar_071141800
#  Bob L.           11/01/07                Added generic <yyyymmdd> pattern for rtvs/vsdb/ncep (e.g., vsdb3.20071026.tar)
#  Bob L.           06/02/08                Added generic <yyyyjjjhhmm> pattern for ssec wf_abba (e.g., f20081522030.namer.v61.g11.filt)
#  Bob L.           12/03/09                Added the NASA VISST pattern (e.g., G11V3.0.RR.2009337.1930.PX.08K.CDF)
#  Bob L.           12/09/09                Added the FIRMS Fire pattern (e.g., MCD14DL.2009343.txt)
#  Bob L.           04/01/10                Added the Level-II raw pattern (e.g., KFTG20100401_214911_V03.raw) & MIT/LL SatCast (20100401T220812Z.nc)
#  Bob L.           08/24/10                Added AOML Radar (in aoml/radar) 'Superobs' (e.g,. 110824H1_1219_1321_radials.so)
#  Bob L.           02/27/12                Added <yyyyjjj_hhmm> for NESDIS GSIP
#-----------------------------------------------------------------------------
#  $Id: fileNameTimeTools.pl,v 1.13 2012/02/27 23:00:56 lipschut Exp $

use Time::Local;


#
# GetFileNameTime()
#
# $fileNameTime = &GetFileNameTime($fileName, $formatStr, $time);
#
# Consider a file name $fileName, which was originally generated under the
# file naming convention indicated by the format string $formatStr.  If the
# file name matches this format, convert it into the corresponding C epoch
# time value and return that, otherwise return $time (which should be its
# creation or last modification time or something).
#
sub GetFileNameTime
    {
    my ($fileName,      # the name of the file
        $formatStr,     # string describing the format used for the file names
        $time) = @_;    # some time associated with this file

    if ($formatStr eq '^<yyjjjhhmm>')
        {
        if ($fileName =~ /^(\d\d)([0-3]\d\d)([0-2]\d)([0-5]\d)/)
            {
            my ($year, $month, $day);
            return $time if ((37 < $1) && ($1 < 70));
            return $time unless ((1 <= $2) && ($2 <= 366) && ($3 < 24));
            $year = ($1 >= 70)? $1 : $1 + 100;
            ($month, $day) = &jdayToMonthDay($2, $year);
            return timegm(0, $4, $3, $day, $month - 1, $year);
            }
        return $time;
        }

    if ($formatStr eq '^<yyjjjhh>')
        {
        if ($fileName =~ /^(\d\d)([0-3]\d\d)([0-2]\d)/)
            {
            my ($year, $month, $day);
            return $time if ((37 < $1) && ($1 < 70));
            return $time unless ((1 <= $2) && ($2 <= 366) && ($3 < 24));
            $year = ($1 >= 70)? $1 : $1 + 100;
            ($month, $day) = &jdayToMonthDay($2, $year);
            return timegm(0, 0, $3, $day, $month - 1, $year);
            }
        return $time;
        }

    if ($formatStr eq '^<yyyyjjjhhmm>')
        {
        if ($fileName =~ /^([12]\d\d\d)([0-3]\d\d)([0-2]\d)([0-5]\d)/)
            {
            my ($month, $day);
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 366)
                      && ($3 < 24));
            ($month, $day) = &jdayToMonthDay($2, $1);
            return timegm(0, $4, $3, $day, $month - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '<yyyyjjjhhmm>')
        {
        if ($fileName =~ /([12]\d\d\d)([0-3]\d\d)([0-2]\d)([0-5]\d)/)
            {
            my ($month, $day);
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 366)
                      && ($3 < 24));
            ($month, $day) = &jdayToMonthDay($2, $1);
            return timegm(0, $4, $3, $day, $month - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '<yyyyjjj.hhmm>')
        {
        if ($fileName =~ /([12]\d\d\d)([0-3]\d\d)\.([0-2]\d)([0-5]\d)/)
            {
            my ($month, $day);
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 366)
                      && ($3 < 24));
            ($month, $day) = &jdayToMonthDay($2, $1);
            return timegm(0, $4, $3, $day, $month - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '<yyyyjjj_hhmm>')
        {
        if ($fileName =~ /([12]\d\d\d)([0-3]\d\d)\_([0-2]\d)([0-5]\d)/)
            {
            my ($month, $day);
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 366)
                      && ($3 < 24));
            ($month, $day) = &jdayToMonthDay($2, $1);
            return timegm(0, $4, $3, $day, $month - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '<yyyyjjj>')
        {
        if ($fileName =~ /([12]\d\d\d)([0-3]\d\d)/)
            {
            my ($month, $day);
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 366));
            ($month, $day) = &jdayToMonthDay($2, $1);
            return timegm(0, 0, 0, $day, $month - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '^<yyyymmddhh>')
        {
        if ($fileName =~ /^([12]\d\d\d)([01]\d)([0-3]\d)([0-2]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, 0, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '^<yyyymmddhhmm>')
        {
        if ($fileName =~ /^([12]\d\d\d)([01]\d)([0-3]\d)([0-2]\d)([0-5]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, $5, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '^<yyyymmdd_hh>')
        {
        if ($fileName =~ /^([12]\d\d\d)([01]\d)([0-3]\d)_([0-2]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, 0, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '^<yyyymmdd_hhmm>')
        {
        if ($fileName =~ /^([12]\d\d\d)([01]\d)([0-3]\d)_([0-2]\d)([0-5]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, $5, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '<yyyymmdd_hhmm>')
        {
        if ($fileName =~ /([12]\d\d\d)([01]\d)([0-3]\d)_([0-2]\d)([0-5]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, $5, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '<yyyymmddThhmm>')
        {
        if ($fileName =~ /([12]\d\d\d)([01]\d)([0-3]\d)T([0-2]\d)([0-5]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, $5, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '^<yyyymmdd-hhmm>')
        {
        if ($fileName =~ /^([12]\d\d\d)([01]\d)([0-3]\d)-([0-2]\d)([0-5]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, $5, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '^[EW]<yymmddhhmm>')
        {
        if ($fileName =~ /^[EW](\d\d)([01]\d)([0-3]\d)([0-2]\d)([0-5]\d)/)
            {
            return $time if ((37 < $1) && ($1 < 70));
            return $time
              unless (   (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, $5, $4, $3, $2 - 1, (($1 >= 70)? $1 : $1 + 100));
            }
        return $time;
        }

    if ($formatStr eq '^g\d+.<yyjjj>.<hhmm>')
        {
        if ($fileName =~ /^g\d+\.(\d\d)([0-3]\d\d)\.([0-2]\d)([0-5]\d)/)
            {
            my ($year, $month, $day);
            return $time if ((37 < $1) && ($1 < 70));
            return $time unless ((1 <= $2) && ($2 <= 366) && ($3 < 24));
            $year = ($1 >= 70)? $1 : $1 + 100;
            ($month, $day) = &jdayToMonthDay($2, $year);
            return timegm(0, $4, $3, $day, $month - 1, $year);
            }
        return $time;
        }

    if ($formatStr eq '^\D*<yyyymmdd>_<hh>')
        {
        if ($fileName =~ /^\D*([12]\d\d\d)([01]\d)([0-3]\d)_([0-2]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, 0, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }


    if ($formatStr eq '^\D*<yyyymmdd>.i<hh>')
        {
        if ($fileName =~ /^\D*([12]\d\d\d)([01]\d)([0-3]\d).i([0-2]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, 0, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }


    if ($formatStr eq '^\D*<yyyymmddhh>')
        {
        if ($fileName =~ /^\D*([12]\d\d\d)([01]\d)([0-3]\d)([0-2]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, 0, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '^\D*<yyyymmdd>')
        {
        if ($fileName =~ /^\D*([12]\d\d\d)([01]\d)([0-3]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31));
            return timegm(0, 0, 0, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '^<yymmddhhmm>')
        {
        if ($fileName =~ /^(\d\d)([01]\d)([0-3]\d)([0-2]\d)([0-5]\d)/)
            {
            return $time if ((37 < $1) && ($1 < 70));
            return $time
              unless (   (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, $5, $4, $3, $2 - 1, (($1 >= 70)? $1 : $1 + 100));
            }
        return $time;
        }

    if ($formatStr eq '<yyyymmdd>_<hhmm>$')
        {
        if ($fileName =~ /([12]\d\d\d)([01]\d)([0-3]\d)_([0-2]\d)([0-5]\d)$/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, $5, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '<yyyymmdd>.<hhmm>')
        {
        if ($fileName =~ /([12]\d\d\d)([01]\d)([0-3]\d)\.([0-2]\d)([0-5]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, $5, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '<yyyymmdd>.<hh>')
        {
        if ($fileName =~ /([12]\d\d\d)([01]\d)([0-3]\d)\.([0-2]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, 0, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '<yyyymmddhh>')
        {
        if ($fileName =~ /([12]\d\d\d)([01]\d)([0-3]\d)([0-2]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, 0, $4, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }

    if ($formatStr eq '<yyyymmdd>')
        {
        if ($fileName =~ /([12]\d\d\d)([01]\d)([0-3]\d)/)
            {
            return $time
              unless (   (1970 <= $1) && ($1 <= 2037)
                      && (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, 0, 0, $3, $2 - 1, $1 - 1900);
            }
        return $time;
        }


    if ($formatStr eq '<yyjjjhhmm>')
        {
        if ($fileName =~ /(\d\d)([0-3]\d\d)([0-2]\d)([0-5]\d)/)
            {
            my ($year, $month, $day);
            return $time if ((37 < $1) && ($1 < 70));
            return $time unless ((1 <= $2) && ($2 <= 366) && ($3 < 24));
            $year = ($1 >= 70)? $1 : $1 + 100;
            ($month, $day) = &jdayToMonthDay($2, $year);
            return timegm(0, $4, $3, $day, $month - 1, $year);
            }
        return $time;
        }


    if ($formatStr eq '<yymmdd\D\d_hhmm>')
        {
        if ($fileName =~ /(\d\d)([01]\d)([0-3]\d)\D\d_([0-2]\d)([0-5]\d)/)
            {
            return $time if ((37 < $1) && ($1 < 70));
            return $time
              unless (   (1 <= $2) && ($2 <= 12)
                      && (1 <= $3) && ($3 <= 31)
                      && ($4 < 24));
            return timegm(0, $5, $4, $3, $2 - 1, (($1 >= 70)? $1 : $1 + 100));
            }
        return $time;
        }

    $time;
    }

#
# jdayToMonthDay()
#
# ($month, $day) = &jdayToMonthDay($jday, $year);
#
# Convert the Julian day $jday (for the year $year) into its equivalent month
# and day values.
#
sub jdayToMonthDay
    {
    my ($jday, $year) = @_;
    my (@days, $i);

    @days = (($year % 4) == 0)?
        (0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366)
      : (0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365);

    for ($i = 1;  $i <= 12;  ++$i)
        {
        return ($i, $jday - $days[$i-1]) if ($jday <= $days[$i]);
        }
    ();
    }


1;
