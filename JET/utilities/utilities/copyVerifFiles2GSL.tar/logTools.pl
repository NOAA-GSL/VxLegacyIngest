#! /usr/local/bin/perl
#! /usr/local/bin/perl -w
#
#-----------------------------------------------------------------------------
#  NOAA/ERL
#  Forecast Systems Laboratory
#  Facility Division
#  Central Facility Management Branch
#  NIMBUS Software
#
#  This software and its documentation are in the public domain and are
#  furnished "as is".  The United States Government, its instrumentalities,
#  officers, employees, and agents make no warranty, express or implied, as to
#  the usefulness of the software and documentation for any purpose.  They
#  assume no responsibility (1) for the use of the software and documentation;
#  or (2) to provide technical support to users.
#
#  logTools.pl  --  tools for standard logging.
#
#  Glen Pankow      11 Sep 97       1.1     Original version.
#                    6 Apr 99       1.2     Boundary condition check.
#                   21 Aug 03       ---     A bit more checking for $logDir.
#  Bob Lipschutz    13 Jan 05               Append pid if logfile already exists
#-----------------------------------------------------------------------------
#  $Id: logTools.pl,v 1.3 2005/03/08 22:23:32 lipschut Exp $


$LogFile = '-';         # the name of the log file

$_LtColumns = 80;       # the maximum number of columns to limit printing to
$_LtTabWidth = 8;       # the width of tabs
$_LtLastTime = 0;       # the time of the last call to LogMessages()
$_LtHourMinSec = '';    # hh:mm:ss prefix portion of $_LtLastTime
$_LtSeqNo = 1;          # per-second sequence number


#
# LogSetOptions()
#
# &LogSetOptions($columns, $tabWidth);
#
# Set the options for the routines of this module.  $columns is the maximum
# number of columns in the logging output (including the prefix characters).
# The default value is 80.  $columns may be specified as < 20, in which case
# there is no limit on the width of the output.  $tabWidth is the number of
# characters between tab stops.  The default value is 8.  $tabWidth must be
# no smaller than 3.
#
# Either $columns or $tabWidth may be undef, in which case the respective
# value is not modified.
#
# Unreasonable values for the arguments are silently changed to something
# more reasonable.
#
sub LogSetOptions
    {
    my ($columns,           # the number of columns to restrict output to
        $tabWidth) = @_;    # the tab stop width value

    if (defined($columns))
        {
        $columns = 9999999 if ($columns < 20);
        $_LtColumns = $columns;
        }
    if (defined($tabWidth))
        {
        $tabWidth = 3 if ($tabWidth < 3);
        $tabWidth = $_LtColumns - 1 if ($tabWidth >= $_LtColumns);
        $_LtTabWidth = $tabWidth;
        }
    }


#
# LogFileOpen()
#
# $success = &LogFileOpen($logDir, $processName);
#
# Create a time-stamped log file name from the name of the current process
# $processName, or $0 if undefined.  A file is then created in the directory
# $logDir (the current working directory if undefined), and STDOUT and STDERR
# are set to write to this log file.  This routine does nothing at all if
# $logDir is passed in as '-'.
#
# The global scalar $LogFile is set with the path to the log file.
#
# LogFileOpen() does not have to be called for LogMessages() to work.
# LogMessages() merely writes to STDOUT, which will not be redirected to a
# file if LogFileOpen() is not called (or it is called with $logDir = '-').
#
# Note that this method of redirecting STDOUT and STDERR to a log file greatly
# simplifies logging, especially for spawned child processes.  (In fact, there
# is no requirement that LogMessages() even needs to be called for logging.)
# Note that the user must take care to wait() for all such spawned children
# lest zombies get created.  Also be warned that some users have encountered
# problems with file redirection in compiled Perl scripts.  This module has NOT
# been tested under a Perl compiler -- programs that use a compiled version of
# this module MIGHT NOT WORK.
#
sub LogFileOpen
    {
    my ($logDir,            # the directory in which to create the log file
        $processName) = @_; # name of the process to use to use in file name
    my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday,
        $LogFile);          # the name of the log file

    #
    # If $logDir = '-', then the user does not wish to redirect STDOUT and
    # STDERR.  Bail out.
    #
    return 1 if (defined($logDir) && ($logDir =~ /^\s*-\s*$/));
    $logDir = '.' unless (defined($logDir));

    #
    # Trim $processName appropriately.  If not defined, use $0.
    #
    $processName = $0 if (!defined($processName));
    $processName =~ s|.*/([^/]+)\s*$|$1|;

    #
    # Check $logDir.  Construct the name of the log file.
    #
    unless (-e $logDir)
        {
        print STDERR
          "$processName:  the log directory '$logDir' does not exist.",
          "  Ignoring it.\n";
        return 0;
        }
    unless (-d _)
        {
        print STDERR
          "$processName:  '$logDir':  not a directory.  Can't log to it:",
          "  Ignoring it.\n";
        return 0;
        }
    ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday) = gmtime(time());
    $LogFile = sprintf('%s.%04d%03d%02d%02d%02d',
      $processName, $year + 1900, $yday + 1, $hour, $min, $sec);
    $LogFile = "$logDir/$LogFile" if ($logDir ne '.');
    $LogFile .= ".$$" if -e $LogFile;

    #
    # Open the log file and do the redirection.  Bail out on error.
    #
    open(_LT_SAVEOUT, ">&STDOUT");
    return 0 if (!open(STDOUT, "> $LogFile"));
    if (!open(STDERR, ">&STDOUT"))
        {
        close(STDOUT);
        open(STDOUT, "&>_LT_SAVEOUT");
        return 0;
        }
    select(STDERR);     $| = 1;     # make unbuffered
    select(STDOUT);     $| = 1;     # make unbuffered

    1;
    }


#
# LogMessages()
#
# &LogMessages(@messages);
#
# @messages is an array of message lines.  The first line in @messages is
# written to the log file prefixed with a timestamp of the form hh:mm:ss.nnn
# (where nnn is a per-second sequence number); subsequent lines are prefixed
# with blanks.  Each line is printed such that wrapping is performed for a
# given number of columns (the $columns argument to LogSetOptions()).  If the
# line would extend past this number of columns, it is automatically broken up
# into several lines at a suitable point (whitespace), with extra indentation
# (of three spaces) added to the remaining lines of the output.
#
# Newline characters may be found in any element in @messages.  Here, a new
# output line is generated at the left-most indentation, although it is
# prefixed with blanks (only the very first line in the very first element of
# @messages is prefixed with the timestamp).
#
# If tab characters are present in a line, the above convention of indentation
# is not used (although the output lines continue to be prefixed).  It is
# assumed that these tabs used for alignment.  The $tabWidth argument to 
# LogSetOptions() may be used to adjust the simple tab stops.
#
# If the first element in @messages is undef, then a prefix of blanks is used
# throughout.
#
# Since breaking up lines happens only at whitespace, really long tokens may
# appear to violate the maximum number of columns specified.
#
# On the very first call to this routine, an initial, complete timestamp line
# is generated.
#
# See the documentation to LogSetOptions() for a description of the various
# options to the routines of this module.
#
sub LogMessages
    {
    my ($thisTime,      # the time of this call
        $needTimeStampPrefix,   # need to print timestamp prefix for first line?
        $messageList,   # the next element of @_ (the array of messages) -- it
                        #   may itself contain multiple lines
        @messages,      # $messageList exploded into separated lines
        $i, $j);        # index counters

    if (($thisTime = time()) != $_LtLastTime)
        {
        my ($sec, $min, $hour);
        if ($_LtLastTime == 0)
            {
            my ($mday, $mon, $year, $wday, $yday);
            ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday)
              = gmtime($thisTime);
            printf("<%4d%03d%02d%02d%02d>\n",
              $year + 1900, $yday + 1, $hour, $min, $sec);
            }
        else
            {
            ($sec, $min, $hour) = gmtime($thisTime);
            }
        $_LtLastTime = $thisTime;
        $_LtHourMinSec = sprintf('%02d:%02d:%02d', $hour, $min, $sec);
        $_LtSeqNo = 1;
        }

    $needTimeStampPrefix = 1;
    for ($i = 0;  $i < @_;  ++$i)
        {
        if (!defined($_[$i]))       # explicit undef?
            {
            $needTimeStampPrefix = 0;   # then just use blank prefix
            next;
            }
        @messages = split(/\s*\n/, $_[$i]);
        for ($j = 0;  $j < @messages;  ++$j)
            {
            if ($needTimeStampPrefix && ($j == 0) && ($i == 0))
                {
                &_LtPrintLine(
                  sprintf("%s.%03d", $_LtHourMinSec, $_LtSeqNo++),
                  $messages[$j]);
                }
            else
                {
                &_LtPrintLine('            ', $messages[$j]);
                }
            }
        }
    }


#
# _LtPrintLine()
#
# &_LtPrintLine($prefix, $line);
#
# Print the line $line, breaking it up so that exdenting is done if the line,
# including the leading prefix string $prefix, does not extend beyond the
# global maximum number of characters in the line $_LtColumns (really long
# tokens, however, are allowed to violate this rule).  Only the first actual
# line printed is prefixed by $prefix; subsequent lines are prefixed by blanks.
#
# If $line contains any tab characters, extra work is done to guarantee that
# tabbing is handled appropriately.
#
# $prefix is assumed to be exactly 12 characters in length.
#
sub _LtPrintLine
    {
    my ($prefix,        # the initial prefix string
        $line) = @_;    # the line to process and emit
    my ($lineLen);      # the length of $line

    #
    # If there are no tabs in the line and if it is a short line, handle this
    # simple case.
    #
    if (!($line =~ /\t/) && (($lineLen = length($line) + 14) <= $_LtColumns))
        {
        print($prefix, '  ', $line, "\n");
        return;
        }

    my (@tokens,        # $line split into alternating space/non-space tokens
        $prefixLen,     # the adjusted length of the line's prefix string
        $whitespace,    # leading whtspc bfr nxt wrd (nxt space tkn in @tokens)
        $spaces,        # $whitespace detabbed (converted into spaces)
        $word,          # next word in $line (next non-space token in @tokens)
        $tokenLen,      # the length of the combined token ($spaces + $word)
        $i);            # index counter

    print($prefix);
    @tokens = split(/(\s+)/, $line);
    shift(@tokens) if ($tokens[0] eq '');
    if ($tokens[0] =~ /^\t/)    # allow a few spaces for tab expansion
        {
        $prefixLen = 12;
        }
    elsif ($tokens[0] =~ /\t/)  # allow a space for tab expansion
        {
        print(' ');
        $prefixLen = 13;
        }
    else                        # use initial line indentation
        {
        print('  ');
        $prefixLen = 14;
        unshift(@tokens, '');
        }
    $lineLen = $prefixLen;
    for ($i = 0;  $i < @tokens - 1;  )
        {
        $whitespace = $tokens[$i++];
        $spaces = &_LtDetabWhitespace($lineLen, $whitespace);
        $word = $tokens[$i++];
        $tokenLen = length($spaces) + length($word);
        if (($lineLen > $prefixLen) && ($lineLen + $tokenLen > $_LtColumns))
            {
            if ($whitespace =~ /^\t/)   # allow a few spaces for tab expansion
                {
                $prefixLen = 12;
                }
            elsif ($whitespace =~ /\t/) # allow a space for tab expansion
                {
                $prefixLen = 13;
                }
            else                        # indent further
                {
                $prefixLen = 17;
                $spaces = '';               #ignore leading whitespace
                }
            print("\n", ' ' x $prefixLen);
            $spaces = &_LtDetabWhitespace($lineLen = $prefixLen, $whitespace);
            $tokenLen = length($spaces) + length($word);
            }
        print($spaces, $word);
        $lineLen += $tokenLen;
        }
    print("\n");
    }


#
# _LtDetabWhitespace()
#
# $whitespace = &_LtDetabWhitespace($lineLen, $whitespace);
#
# Convert any tab characters in $whitespace to spaces based on the current
# global tab width value, $_LtTabWidth.  The number of characters already
# printed in the current line is given by $lineLen.
#
sub _LtDetabWhitespace
    {
    my ($lineLen,           # the number of chars already output this line
        $whitespace) = @_;  # the whitespace text to convert tabs in
    my (@spaces,            # $whitespace exploded into separate characters
        $space,             # one of these characters
        $noTabSpaces);      # the number of spaces that replaces a tab

    return $whitespace unless ($whitespace =~ /\t/);
    @spaces = split('', $whitespace);
    $whitespace = '';
    foreach $space (@spaces)
        {
        if ($space eq "\t")
            {
            $noTabSpaces = $_LtTabWidth - ($lineLen % $_LtTabWidth);
            $whitespace .= ' ' x $noTabSpaces;
            $lineLen += $noTabSpaces;
            }
        else
            {
            $whitespace .= ' ';
            $lineLen++;
            }
        }
    $whitespace;
    }


1;


__END__     # test code follows


&LogFileOpen('.', 'bubba') || die "!!!\n!!! open failed:  $!\n!!!\n";

&LogMessages("hey, baby", "ready, freddy!\nor else...", "so, what?");
sleep(1);
&LogMessages(undef, "  to be or not to be;", "that is the question");
sleep(1);
&LogMessages("how much wood would a woodchuck chuck"
             . "  if a woodchuck could chuck        wood?"
             . "   Or, is 'nama mugi, nama gome, nama tamago' hard to say?");
&LogMessages("there are\ttabs\tsurrounding the word 'tabs'");
print
  "          1         2         3         4         5         6         7\n";
print '0123456789' x 8, "\n";
# &LogSetOptions(60, 6);
print ' ' x $_LtTabWidth, 'v', ' ' x ($_LtTabWidth - 1),
  'v', ' ' x ($_LtTabWidth - 1), 'v', ' ' x ($_LtTabWidth - 1),
  'v', ' ' x ($_LtTabWidth - 1), 'v', ' ' x ($_LtTabWidth - 1),
  'v', ' ' x ($_LtTabWidth - 1), 'v', ' ' x ($_LtTabWidth - 1), "v\n";
&LogMessages("\tto\tbe\tor\tnot\tto\tbe;\t  that\tis\tthe\t question,\tbaby."
             . "\t  nama\tmugi,\tnama\tgome,\tnama\ttamago");
&LogMessages("trailing whitespace!!!    ", 'me, too!  ');

# $str = '-fred-mark-ted-glen-';
# print "\n\$str = \"$str\"\n";
# @strs = split(/(-)/, $str);
# shift(@strs) if ($strs[0] eq '');
# print "\@strs = (\"", join('", "', @strs), "\")\n";
