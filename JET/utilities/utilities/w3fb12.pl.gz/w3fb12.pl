#
# this expects lower left corner to be $xi = 1, $xj = 1;
#
# converted from C by WRM 17-Mar-2005
#
#  88-11-25  original author:  stackpole, w/nmc42

sub w3fb12($xi,$xj,$alat1,$elon1,$dx,$elonv,$alatan) {
    ($xi,$xj,$alat1,$elon1,$dx,$elonv,$alatan) = @_;
    my($alat,$elon);
    my($rerth,$pi,$radpd,$rebydx,$alatn1,$an,$cosltn,$elon1L,$elonL,$elonvr);
    my($ala1,$rmLL,$elo1,$arg,$polei,$polej,$ala,$rm,$elo,$h);
    my($beta,$piby2,$xx,$yy,$r2,$aninv,$aninv2,$thing,$degprd,$theta);

    $rerth =6.3712e+6;
    $pi=3.14159;
    $beta  = 1.;

    #  h = 1 for northern hemisphere; = -1 for southern
    if($alatan > 0) {
	$h = 1.;
    } else {
	$h = -1.;
    }
  
    $piby2 = $pi/2.;
    $radpd = $pi/180.0;
    $degprd = 1./$radpd;
    $rebydx = $rerth/$dx;
    $alatn1 = $alatan * $radpd;
    $an = $h * sin($alatn1);
    $cosltn = cos($alatn1);
    
    # make sure that input longitude does not pass through
    # the cut zone (forbidden territory) of the flat map
    # as measured from the vertical (reference) longitude
    
    $elon1L = $elon1;
    if(($elon1 - $elonv) > 180.) {
	$elon1L = $elon1 - 360.;
    }
    if(($elon1 - $elonv) < (-180.)) {
	$elon1L = $elon1 + 360.;
    }
    
    $elonL = $elon;
    if(($elon  - $elonv) > 180.) {
	$elonL  = $elon  - 360.;
    }
    if(($elon - $elonv) < (-180.)) {
	$elonL = $elon + 360.;
    }
    
    $elonvr = $elonv * $radpd;

    #  radius to lower left hand (ll) corne
    $ala1 =  $alat1 * $radpd;
    $rmLL = $rebydx * ($cosltn**(1.-$an))*((1.+$an)**$an) *
	((cos($ala1)/(1.+$h*sin($ala1)))**$an)/$an;

    #  use ll point info to locate pole point
    $elo1 = $elon1L * $radpd;
    $arg = $an * ($elo1-$elonvr);
    $polei = 1. - $h * $rmLL * sin($arg);
    $polej = 1. + $rmLL * cos($arg);

    # radius to the i,j point (in grid units)
    # yy reversed so positive is down
    
    $xx = $xi - $polei;
    $yy = $polej - $xj;
    $r2 = ($xx**2) + ($yy**2);
  
    # check that the requested i,j is not in the forbidden zone
    # yy must be positive up for this test
    
    $theta = $pi*(1.-$an);
    $beta = abs(atan2($xx,-$yy));
    if($beta <= $theta){
	$alat = 999.;
	$elon = 999.;
    } else {
	if($r2 == 0) {
	    $alat = $h * 90.;
	    $elon = $elonv;
	} else {
	    $elon = $elonv + $degprd * atan2($h*$xx,$yy)/$an;
	    if($elon > 180) {
		$elon -= 360.;
	    } elsif($elon < -180) {
		$elon += 360;
	    }
	    $aninv = 1./$an;
	    $aninv2 = $aninv/2.;
	    $thing = (($an/$rebydx)**$aninv)/
		(($cosltn**((1.-$an)*$aninv))*(1.+ $an));
	    $alat = $h*($piby2 - 2.* atan2($thing*($r2**$aninv2),1))*$degprd;
	}
    }
    return ($alat,$elon);
}
1;
