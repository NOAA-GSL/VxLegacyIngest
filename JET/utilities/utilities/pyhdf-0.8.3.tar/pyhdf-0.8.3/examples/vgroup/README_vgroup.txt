These two samples demonstrate reading and writing Vgroup-type hdf files.

TODO: Better documentation
