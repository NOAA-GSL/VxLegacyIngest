This example script creates a data array and stores it as an HDF file under several different compression formats.

TODO: More outputs from the code displayed at the command line.
